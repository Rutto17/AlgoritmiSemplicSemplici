﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stampare_i_multipli_di_7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Stampo i multipli di 7 esclusi tra 12 - 75 e 417 - 492");
            for (int i = 0; i < 500; i++)
            {
                int b = 0;
                int s = 7 * b;
                
                if (s > 12 && s < 75 || s > 417 && s < 492)
                {
                    b++;
                }
                else
                {
                    Console.WriteLine(s);
                    b++;
                }

            }
            Console.ReadKey();
        }
    }
}
