﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quadrato_Magico
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.Visible = false;
            label2.Visible = false;
            button2.Enabled = false;
        }

        //    int[,] array;
        double quanteCelle;
        private void button1_Click(object sender, EventArgs e)
        {
            button2.Enabled = true;
            dataGridView1.Visible = true;
            double n = Convert.ToInt32(textBox1.Text);
            dataGridView1.RowCount = Convert.ToInt32(n);
            dataGridView1.ColumnCount = Convert.ToInt32(n);
            //  int[,] array = new int[n, n];
            quanteCelle = n;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double respect = 0;
            double appoggio = 0;

            for (double i = 0; i < quanteCelle; i++)
            {
                appoggio = appoggio + SommatoreRighe(i);
            }
            if ((appoggio / quanteCelle) == SommatoreRighe(0))
            {
                respect = appoggio / quanteCelle;
            }
            else
            {
                label2.Text = "No square magic";
            }
            appoggio = 0;
            for (double i = 0; i < quanteCelle; i++)
            {
                appoggio = appoggio + SommatoreColonne(i);
            }
            if (appoggio / quanteCelle == respect)
            {
                label2.Text = "È quasi magico";
            }
            else
            {
                label2.Text = "colonne non magiche";
            }
            double diagonali = SommaDiagonali();
            if ((diagonali) / 2 == respect)
            {
                label2.Visible = true;
                label2.Text = "Il quadrato è magico!!";
            }
            else
            {
                label2.Visible = true;
                label2.Text = "Non è magico";
            }
        }












        public double SommatoreRighe(double i)
        {
            double z = 0;
            for (double s = 0; s < quanteCelle; s++)
            {
                z = z + Convert.ToDouble(dataGridView1.Rows[Convert.ToInt32(i)].Cells[Convert.ToInt32(s)].Value);
            }
            return z;
        }

        public double SommatoreColonne(double i)
        {
            double z = 0;
            for (double s = 0; s < quanteCelle; s++)
            {
                z = z + Convert.ToDouble(dataGridView1.Rows[Convert.ToInt32(s)].Cells[Convert.ToInt32(i)].Value);
            }
            return z;
        }
        public double SommaDiagonali()
        {
            double v = quanteCelle - 1;
            double diagonale1 = 0;
            double diagonale2 = 0;
            for (int i = 0; i < quanteCelle; i++)
            {
                diagonale1 = diagonale1 + Convert.ToInt32(dataGridView1.Rows[i].Cells[i].Value);
            }
            for (int i = 0; i < quanteCelle; i++)//qua ghe sè problemi con l if
            {
                if ((v - i) >= 0)
                {
                    diagonale2 = diagonale2 + Convert.ToInt32(dataGridView1.Rows[i].Cells[Convert.ToInt32(v-i)].Value);
                }
            }
            return diagonale1 + diagonale2;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            label2.Visible = false;
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            label2.Visible = false;
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            
        }

        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
          
            {
                e.Handled = true;
            }
        }
    }
}