﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Espressione
{
    class Espressione
    {
        /*private string s;
        private char[] stringa;
        private int numeroParentesi = 0;
        private int[] aperte = { };
        private int[] chiuse = { };

        public Risolvi(string a, char[] b,int c,int[] d,int[] e)
        {
            s = a;
            stringa = b;
            numeroParentesi = c;
            aperte = d;
            chiuse = e;
        }
        private void ContaParentesi()
        {
            for (int i = 0; i == s.Length; i++)
            {
                if (stringa[i] == '(')
                {
                    if (aperte.Length == 0)
                    {
                        aperte[0] = i;
                    }
                    else
                    {
                        Array.Resize(ref aperte, aperte.Length + 1);
                        aperte[aperte.Length] = i;
                    }

                }
                else if (stringa[i] == '(')
                {
                    if (chiuse.Length == 0)
                    {
                        chiuse[0] = i;
                    }
                    else
                    {
                        Array.Resize(ref chiuse, chiuse.Length + 1);
                        chiuse[chiuse.Length] = i;
                    }
                }
            }
        }*/
    }
}
