﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anno_Bisestile
{
    class Program
    {
        static void Main(string[] args)
        {
            int anno, s, t, z;
            double q, r;
            Console.WriteLine("Scrivi un anno");
            anno = Convert.ToInt32(Console.ReadLine());

            if (anno >= 1582)
            {
                z = anno;
                t = z / 100;
                r = Convert.ToDouble(z) / 100;
                if (t == r)
                {
                    s = anno / 400;
                    q = Convert.ToDouble(anno) / 400;

                    if (s == q)
                    {
                        Console.WriteLine("L'anno è bisestile");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("L'anno non è bisestile");
                        Console.ReadKey();
                    }
                }
                else
                {
                    s = anno / 4;
                    q = Convert.ToDouble(anno) / 4;

                    if (s == q)
                    {
                        Console.WriteLine("L'anno è bisestile");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("L'anno non è bisestile");
                        Console.ReadKey();
                    }
                }

            }
            else
            {
                Console.WriteLine("L' anno non è bisestile");
                Console.ReadKey();
            }
        }
    }
}
