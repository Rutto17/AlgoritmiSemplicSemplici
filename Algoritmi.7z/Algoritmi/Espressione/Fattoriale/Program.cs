﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fattoriale
{
    class Program
    {
        private static int Fattoriale(int number)
        {
            if (number < 0)
                return 0;
            else if (number <= 1)
                return 1;
            else
            {
                int moltiplicazione = 1;
                for (int i = 2; i <= number; i++)
                {
                    moltiplicazione = moltiplicazione * i;
                }
                return moltiplicazione;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Scrivi il numero da fattorizzare");
            int scrivimi = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(Fattoriale(scrivimi));
            Console.ReadKey();
        }

    }

}
